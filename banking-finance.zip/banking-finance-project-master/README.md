# banking-finance-project
# DevOps project 
An end to end CI-CD projects implemented to build, containerize, deploy the app to testing env on EC2 , selenium testing and deploy the app to prod env on EC2 .
created aws infra using terraform.
detailed monitoring of nodes and containers using prometheus and grafana.




![](https://github.com/praveensirvi1212/banking-finance-project/blob/master/images/Screenshot%20from%202023-05-16%2000-06-04.png)
